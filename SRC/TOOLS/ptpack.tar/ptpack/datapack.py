#----------#
# Header
#----------#
# import sci_meshgrid
import csv
import numpy as np
# import pylab as pl
# from matplotlib import pyplot as plt
# from matplotlib import animation as animation
# import sys
# import os
# import types

import Scientific.IO.NetCDF as netcdf
# import Numeric
# import NetCDF

import ptpack.parameter as ppp
import re

#**********#
# The class is a dictionary for variables
#**********#
class VarInfo(object):
  '''
  '''

  def __init__(self, name, disname, unit, disunit, dscp):
    self.name = name
    self.disname = name
    self.unit = name
    self.disunit = name
    self.dscp = dscp

class VarInfoMeteo(VarInfo):
  def __init__(self, name, disname, unit, disunit, dscp):
    super(VarInfoMeteo, self).__init__(name, disname, unit, disunit, dscp)
    # VarInfo.__init__(self, name, disname, unit, disunit, dscp)

class VarInfoChem(VarInfo):
  def __init__(self, molarmass, *args):
    super(VarInfoChem, self).__init__(*args)
    self.molarmass = molarmass


class VarLib:
  '''
  '''

  def __init__(self):
    #===== Set the dictionary for variables
    # name: display name, unit, display unit, description
    self.lib = {
      'u': VarInfoMeteo('u', 'u', 'm s-1', r'm/s', 'u wind'),
      'v': VarInfoMeteo('v', 'v', 'm s-1', r'm/s', 'v wind'),
      'w': VarInfoMeteo('w', 'w', 'm s-1', r'm/s', 'w wind'),
      'theta': VarInfoMeteo('theta', r'$\theta$', 'K', 'K', 'potential temperature'),
      'thetarho': VarInfoMeteo('thetarho', r'$\theta_\rho$', 'K', 'K', 'density potential temperature'),
      'rho': VarInfoMeteo('rho', r'$\rho$', 'kg m-3', r'kg m$^{-3}$', 'density'),
      'tke': VarInfoMeteo('tke', 'TKE', 'm2 s2', r'm$^2$ s$^{-2}$', 'turbulent kinetic energy'),
      'qv': VarInfoMeteo('qv', r'$q_v$', 'kg m-3', r'kg m$^{-3}$', 'specific humidity'),
      'pre': VarInfoMeteo('pre', 'Pres', 'hPa', 'hPa', 'Pressure'),
      'diffpot': VarInfoMeteo('diffpot', r'$\niu_h$', 'm2 s-1', r'm$^2$ s$^{-1}$', 'Eddy diffusivity for scalars'),
      'diffmom': VarInfoMeteo('diffmom', r'$\niu_m$', 'm2 s-1', r'm$^2$ s$^{-1}$', 'Eddy diffusivity for momentum'),
      'abstemp': VarInfoMeteo('abstemp', 'T', 'K', 'K', 'absolute temperature'),
      'ISO': VarInfoChem('ISO', 'Isoprene', 'molec cm-3', r'molec cm$^{-3}$', 'isoprene', 68.0),
      'API': VarInfoChem('API', r'$\alpha$-pinene', 'molec cm-3', r'molec cm$^{-3}$', 'alpha-pinene', 136.0),
      'BPI': VarInfoChem('BPI', r'$\beta$-pinene', 'molec cm-3', r'molec cm$^{-3}$', 'beta-pinene', 136.23),
      'LIMN': VarInfoChem('LIMN', 'Limonene', 'molec cm-3', r'molec cm$^{-3}$', 'limonene', 136.0),
      'CAR3': VarInfoChem('CAR3', r'$\Delta 3$-carene', 'molec cm-3', r'molec cm$^{-3}$', 'Delta3-carene', 136.24),
      'OH': VarInfoChem('OH', 'OH', 'molec cm-3', r'molec cm$^{-3}$', 'OH', 17.0),
      'HO2': VarInfoChem('HO2', r'HO$_2$', 'molec cm-3', r'molec cm$^{-3}$', 'HO2', 33.0),
      'O3': VarInfoChem('O3', r'O$_3$', 'molec cm-3', r'molec cm$^{-3}$', 'Ozone', 48.0)
      # 'so2': VarInfoChem('SO2', r'SO$_2$', r'molec cm$^{-3}$', 0.8e10, 1.30e10),
      # 'no': VarInfoChem('NO', 'NO', r'molec cm$^{-3}$', 0.0, 1.0e9),
      # 'no2': VarInfoChem('NO2', r'NO$_2$', r'molec cm$^{-3}$', 0.0, 6.0e9),
      # 'no3': VarInfoChem('NO3', r'NO$_3$', r'molec cm$^{-3}$', 0.0, 1.0e6),
      # 'co': VarInfoChem('CO', 'CO', r'molec cm$^{-3}$', 2.12e12, 2.50e12),
      # 'bcar': VarInfoChem('BCAR', 'BCAR', r'molec cm$^{-3}$', 0.0, 3.0e8),
      # 'farn': VarInfoChem('FARN', 'FARN', r'molec cm$^{-3}$', 0.0, 5.0e7),
      }

  def __str__(self):
    # for name in self.lib:
    #   print name
    #   for prop in self.lib[name]:
    #     print '  ' + prop
    # return str(self.lib)
    return 'name: Var(name, display name, unit, display unit, description)'

  def get_disname(self, name):
    #===== return the display name
    return self.lib[name].disname

  def get_unit(self, name):
    #===== return the unit
    return self.lib[name].unit

  def get_disunit(self, name):
    #===== return the display unit
    return self.lib[name].disunit

  def get_dscp(self, name):
    #===== return the description
    return self.lib[name].dscp


#**********#
# Define the class for saving parameters in asam grid file
#**********#
class GridData:
  '''
  Read the parameters of the model from the grid file 'gridfile', the grid file is usually in the form of '*.grid'.
  Save the data in the object.
  '''

  def __init__(self, gridfile):
    #===== Set regular expression for numbers
    p = re.compile('([0-9\.dDeE+-]*[0-9])')
    with open(gridfile, 'r') as f:
      #===== Set the position to the very first
      f.seek(0,0)
      #===== Read the file line by line
      line = f.readline()
      while line:
        if line.find('#Gitter') >= 0:
          #===== Find x0, x1, nx, y0, y1, ny, z0, z1, nz
          line = f.readline() # 'cart'
    
          line = f.readline() # x0, x1, nx
          line = re.sub(r'd', 'e', line) # change 'd' to 'e'
          matchObj = re.findall(p,line)
          self.x0 = float(matchObj[0])
          self.x1 = float(matchObj[1])
          self.nx = int(matchObj[2])
          self.dx = (self.x1-self.x0)/self.nx
          self.xx = np.linspace(self.x0+self.dx/2.0,self.x1-self.dx/2.0,self.nx)
    
          line = f.readline() # y0, y1, ny
          line = re.sub(r'd', 'e', line) # change 'd' to 'e'
          matchObj = re.findall(p,line)
          self.y0 = float(matchObj[0])
          self.y1 = float(matchObj[1])
          self.ny = int(matchObj[2])
          self.dy = (self.y1-self.y0)/self.ny
          self.yy = np.linspace(self.y0+self.dy/2.0,self.y1-self.dy/2.0,self.ny)
    
          line = f.readline() # z0, z1, nz
          line = re.sub(r'd', 'e', line) # change 'd' to 'e'
          matchObj = re.findall(p,line)
          self.z0 = float(matchObj[0])
          self.z1 = float(matchObj[1])
          self.nz = int(matchObj[2])
          self.dz = (self.z1-self.z0)/self.nz
          self.zz = np.linspace(self.z0+self.dz/2.0,self.z1-self.dz/2.0,self.nz)
        elif line.find('zGrid') >=0:
          #===== Get zz if the resolutions in z direction change
          line = f.readline() # number of different resolution areas
          matchObj = re.findall(p,line)
          ndr = int(matchObj[0])
          izstr = 0
          izend = 0
          self.dz = np.zeros(self.nz)
          self.zz = np.zeros(self.nz)
          for ii in np.arange(ndr):
            line = f.readline() # zr0,zr1,nzr
            matchObj = re.findall(p,line)
            zr0 = float(matchObj[0])
            zr1 = float(matchObj[1])
            nzr = int(matchObj[2])
            izstr = izend
            izend = izend + nzr
            self.dz[izstr:izend] = (zr1-zr0)/nzr
            dzr = self.dz[izstr]
            self.zz[izstr:izend] = np.linspace(zr0+dzr/2.0,zr1-dzr/2.0,nzr)
        elif line.find('dtStart') >= 0:
          #===== Get time step
          line = re.sub(r'd', 'e', line)
          matchObj = re.findall(p,line)
          self.dt = float(matchObj[0])
        elif line.find('StartTime') >= 0:
          #===== Get start time
          line = re.sub(r'd', 'e', line)
          matchObj = re.findall(p,line)
          self.t0 = float(matchObj[0])
        elif line.find('EndTime') >= 0:
          #===== Get start time
          line = re.sub(r'd', 'e', line)
          matchObj = re.findall(p,line)
          self.t1 = float(matchObj[0])
        elif line.find('OutputTimeStep') >= 0:
          #===== Get output time step
          line = re.sub(r'd', 'e', line)
          matchObj = re.findall(p,line)
          self.odt = float(matchObj[0])
        elif line.find('#CanopyLayers') >= 0:
          #===== Get number of canopy layers and LAD
          #----- Get number of canopy layers 'ncap'
          line = f.readline()
          matchObj = re.findall(p,line)
          self.ncap = float(matchObj[0])
          #----- Get LAD
          line = re.sub(r'd', 'e', f.readline())
          matchObj = re.findall(p,line)
          self.LAD = np.array([float(i) for i in matchObj])

        line = f.readline()


#**********#
# Define the class for reading ASAM data
#**********#
class AsamDataPack:
  '''
  ' Read the data from the netcdf file generated by ASAM and define the properties for variables.
  '
  ' data: values of variable
  ' nameFile: variable's name in nc file
  ' nameDis: variable's name used for display
  ' unit: variable's unit
  ' min: minimum value
  ' max: maximum value
  '
  ' This class needs:
  '   numpy, matplotlib.pyplot, os
  '
  '''

  # dir = '/media/My Passport/Data/ASAM_P1/CanopyTest/case_20140216_cfesc_3200-3200-2405_64-64-100/'
  # dir = '/home/pzzhou/Scripts/Fortran/ASAM_P1/CanopyTest/case_20140305_3200-3200-2405/'
  # nc_file = netcdf.NetCDFFile(dir+'Canopy_20100806_14_3200_60.nc','r') # case_20131009_cfesn_48-48-48_480_480_2405_29558_lai5_profile-20100716-140000

  def __init__(self, folder='./', ncfile='.nc', gdfile='.grid'):
    #===== Initiate the class with folder and netcdf file names
    self.folder = folder
    self.ncfile = ncfile
    self.fileid = netcdf.NetCDFFile(self.folder+self.ncfile, 'r')
    self.gdfile = gdfile
    self.gd = GridData(self.folder+self.gdfile)

  def get_data(self, dataname):
    #===== Get data from netcdf file
    data = np.array(self.fileid.variables[dataname])
    #----- Change the unit from [ug m-3] to [molec cm-3]
    if dataname in ppp.chem_list:
      molar_mass = ppp.chem_list[dataname]
      # print data
      data = data*1.0e-6/molar_mass*ppp.NA*1.0e-6
    return data

  def tke_resolved(self, t_array, t_start, t_end):
    '''
    Calculate resolved turbulent kinetic energy, the data dimensions are [time, lev, yc, xc].
    't_array' has the same length as the first dimension of the data.
    Returned array is tke_res[lev].
    '''
    #===== Read data for u, v and w
    u = self.get_data('U')
    v = self.get_data('V')
    w = self.get_data('W')
    #===== Get dimensions of u, v and w
    dims = u.shape
    #===== Obtain the time and horizontal average of u, v and w (u_ave[lev], v_ave[lev], w_ave[lev])
    u_ave = np.mean( np.mean( np.mean( u[(t_array>=t_start) & (t_array<=t_end), :, :, :], axis=3 ), axis=2 ), axis=0 )
    v_ave = np.mean( np.mean( np.mean( v[(t_array>=t_start) & (t_array<=t_end), :, :, :], axis=3 ), axis=2 ), axis=0 )
    w_ave = np.mean( np.mean( np.mean( w[(t_array>=t_start) & (t_array<=t_end), :, :, :], axis=3 ), axis=2 ), axis=0 )
    #===== Obtain the fluctuations of u, v and w
    u_flu = u - np.tile( u_ave[np.newaxis, :, np.newaxis, np.newaxis], [dims[0], 1, dims[2], dims[3]] )
    v_flu = v - np.tile( v_ave[np.newaxis, :, np.newaxis, np.newaxis], [dims[0], 1, dims[2], dims[3]] )
    w_flu = w - np.tile( w_ave[np.newaxis, :, np.newaxis, np.newaxis], [dims[0], 1, dims[2], dims[3]] )
    #===== Calculate resolved TKE, [lev]
    tke_res = 0.5*np.mean( np.mean ( np.mean( u_flu*u_flu + v_flu*v_flu + w_flu*w_flu, axis=3 ), axis=2 ), axis=0 )
    return tke_res

  def tke_sgs(self, t_array, t_start, t_end):
    '''
    Calculate subgrid-scale turbulent kinetic energy, the data dimensions are [time, lev, yc, xc].
    't_array' has the same length as the first dimension of the data.
    Returned array is tke_sgs[lev].
    '''
    tke = self.get_data('TKE')
    tke_sgs = np.mean( np.mean( np.mean( tke[(t_array>=t_start) & (t_array<=t_end), :, :, :], axis=3 ), axis=2 ), axis=0 )
    return tke_sgs
    
  def flux_resolved(self, data):
    '''
    Calculate resolved flux from model data, the data dimensions are [time, lev, yc, xc]
    '''
    w = self.get_data('W')
    fr = np.mean(np.mean(data*w, axis=3), axis=2)
    return fr

  def flux_sgs(self, data, zz, dz):
    '''
    Calculate subgrid-scale flux from model data, the data dimensions are
    data[time, lev, yc, xc], diff[time, lev, yc, xc], zz[lev], dz[lev]
    'data' is the selected quantity, 'diff' is the eddy viscosity for scalars
    '''
    #===== Calculate z values for boundaries of grid cells
    zz_bound = np.zeros(zz.size+1)
    zz_bound[0:-1] = zz - dz*0.5
    zz_bound[-1] = zz[-1] + dz[-1]*0.5
    #===== Calculate the difference of data with respect to z
    dims = data.shape
    ddata_dz = np.zeros(data.shape)
  
    for iit in np.arange(dims[0]): # indices for time
      for iiy in np.arange(dims[2]): # indices for level
        for iix in np.arange(dims[3]): # indices for y
          #----- Calculate interpolated values of data at boundaries of grid cells
          data_bound = np.interp(zz_bound, zz, data[iit, :, iiy, iix], left=0.0)
          #----- Calculate d_data / d_z
          ddata_dz[iit,:,iiy,iix] = (data_bound[1:]-data_bound[0:-1]) / dz
  
    diff = self.get_data('DIFFPOT')
    fs = np.mean(np.mean(-diff, axis=3), axis=2) * np.mean(np.mean(ddata_dz, axis=3), axis=2)
    return fs

  def scale(self):
    NA = ppp.NA
    temp = DataPack.nc_file.variables[self.nameFile]
    if self.nameFile == 'ISO':
      self.data = np.array(temp)*1.0e-6/68.12*NA*1.0e-6
      self.unit = r'#/cm$^3$'
      self.max = 1.0e9
    else:
      self.data = np.array(temp)
#**********#
# Define the class for reading SOSA data
#**********#
class SosaDataPack:
  '''
  ' This class is used to read output data from SOSA.
  '''
  def __init__(self, folder='./'):
    #===== Obtain the folder where the data files are saved =====#
    self.folder = folder
    #===== List the file names corresponding to the variable names in ASAM =====#
    self.var_to_file = {
      'U'       : 'UUU.dat',
      'V'       : 'VVV.dat',
      'W'       : 'WWW.dat',
      'WIND'    : 'WIND.dat',
      'AbsTemp' : 'TTT.dat',
      'TKE'     : 'TKE.dat',
      'API'     : 'GAS_apin.dat',
      'ISO'     : 'GAS_isop.dat',
      'OH'      : 'GAS_oh.dat',
      'BCAR'    : 'GAS_bcar.dat',
      'FARN'    : 'GAS_farn.dat',
      'SO2'     : 'GAS_so2.dat'
      }

  def get_data(self, var_name):
    temp = np.loadtxt(self.folder+self.var_to_file[var_name])

    zz = temp[0, 6:]
    tt = temp[1:, 0:6]
    data = temp[1:, 6:]

    return (data, zz, tt)

  def get_index_at_time(self, tt, time_str='20100801_000000'):
    '''
    ' tt is the array of dates and is in the form of [ [2010 8 1 0 0 0], [2010 8 1 0 30 0], ... ].
    ' This function can find the index of the element which represents the time in the time_str.
    '''
    tt_int = tt.astype(int)
    for ii in np.arange(tt_int.shape[0]):
      tt_str = '{0:04d}{1:02d}{2:02d}_{3:02d}{4:02d}{5:02d}'.format(*tt_int[ii, :])
      if tt_str == time_str:
        return ii
    #===== if the time is not found, return -1 as the error number =====#
    return -1


#**********#
# Define the class for reading the Sounding data in the HUMPPA campaign
#**********#
class SoundDataPack:
  '''
  ' This class is used to read the sounding data.
  ' height [m], pressure [hPa], theta [K], wind [m/s], wd [deg], u [m/s], v [m/s], qv [g/kg]
  ' Example:
  ' #=====#
  ' sdk = SoundDataPack('/the/path/of/data/files/')
  ' time_str = ['20100717_120413', '20100717_140415']
  ' data = sdk.get_data(time_str, 'U')
  ' #=====#
  ' Then data[0] is a 1D array of U in '20100717_120413.txt', data[1] is for '20100717_140415'.
  ' Here we should notice that data[0] and data[1] usually have different numbers of elements.
  '''
  #===== List the indices of variables in the files =====#
  var_to_ind = {
    'U'     : 5,
    'V'     : 6,
    'WIND'  : 3,
    'WD'    : 4,
    'lev'   : 0, 
    'PRE'   : 1,
    'THETA' : 2,
    'QV'    : 7
    }

  def __init__(self, folder='./'):
    #===== Obtain the folder where the data files are saved =====#
    self.folder = folder # /media/My Passport/Data/HUMPPA/Sounding.Data/New.Data.Set/

  def get_data(self, time_str, var_name):
    '''
    ' Get data from specific time shown in time_str, it can contain many time strings.
    ' This function returns a list of time series of variables
    '''
    data_list = []
    for tstr in time_str:
      file_name = tstr + '.txt'
      temp = np.loadtxt(self.folder + file_name, skiprows=1)
      data_list.append(temp[:, SoundDataPack.var_to_ind[var_name]])

    return data_list


#**********#
# Define the class for reading the SMEAR II data downloaded from SmartSMEAR
#**********#
class SmearDataPack:
  '''
  ' Read the data downloaded from SmartSMEAR.
  '''
  #===== List of the units for variables =====#
  var_to_unit = {
    'Glob': 'W m-2',
    'RGlob': 'W m-2',
    'Net': 'W m-2',
    'Time': 'yyyymmddHHMMSS'
    }

  def __init__(self, folder='./'):
    self.folder = folder # /media/My Passort/Data/HUMPPA/SmartSMEAR.Data/

  def get_data(self, filename, var_name):
    '''
    ' Return a 1D array of variable data or 2D array of time (yyyymmddHHMMSS)
    '''
    #===== Get the header list =====#
    with open(self.folder + filename, 'rb') as f:
      reader = csv.reader(f)
      for row in reader:
        header = row
        break
    #===== Read the data =====#
    temp = np.genfromtxt(self.folder+filename, dtype=float, delimiter=',', skip_header=1)
    if var_name == 'Time':
      return temp[:, 0:6]
    else:
      return temp[:, header.index(var_name)]

  def get_unit(self, var_name):
    '''
    ' Get the unit of variable
    '''
    return SmearDataPack.var_to_unit[var_name]

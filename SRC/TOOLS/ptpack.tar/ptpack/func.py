import numpy as np
import re

def secondsofday_to_hms(seconds):
  '''
  Convert seconds of a day to HH, MM, SS
  '''
  HH = int(seconds/3600.0)
  MM = int( (seconds-HH*3600.0)/60.0 )
  SS = int(seconds-3600.0*HH-60.0*MM)
  return (HH,MM,SS)

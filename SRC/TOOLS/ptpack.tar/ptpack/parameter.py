NA  = 6.0221413e23  # [# mol-1], Avogadro's number
kB  = 1.3806488e-23 # [m2 kg s-2 K-1], Boltzmann constant
Eps = 1.0e-20       # used in denominator to prevent divided by 0

R   = 8.3144621     # [J K-1 mol-1], gas constant
Md  = 28.9645e-3    # [kg mol-1], molar mass of dry air
Mv  = 18.01528e-3   # [kg mol-1], molar mass of water vapor
Rd  = R/Md          # [J K-1 kg-1], specific gas constant of dry air
Rv  = R/Mv          # [J K-1 kg-1], specific gas constant of water vapor
cpd = 1004.0        # [J kg-1 K-1], specific heat capacity at constant pressure
cvd = 717.0         # [J kg-1 K-1], specific heat capacity at constant volume
cpv = 1885.0        # [J kg-1 K-1], specific heat capacity for water vapor at constant pressure
cvv = 1424.0        # [J kg-1 K-1], specific heat capacity for water vapor at constant volume
cpl = 4186.0        # [J kg-1 K-1], specific heat capacity for liquid water at constant pressure

p0 = 1.0e5          # [Pa], reference pressure



#----- Molar masses for different gases in the unit of [g mol-1]
chem_list = {
  'ISO' : 68.0,
  'API' : 136.0,
  'BPI' : 136.23,
  'LIMN': 136.0,
  'CAR3': 136.24,
  'HO'  : 17.0,
  'HO2' : 33.0,
  'O3'  : 48.0,
  'SO2' : 64.0,
  'NO'  : 30.0,
  'NO2' : 46.0,
  'NO3' : 62.0,
  'CO'  : 28.0,
  'BCAR': 204.36,
  'FARN': 204.00
  }
